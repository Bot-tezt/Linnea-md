while true
do
echo "Starting Venocyber-md!"
node .
done
